package com.streamai.studio.ai

interface AIDirector {
 fun start()
 fun stop()
 fun markHighlight(timestampMs:Long)
}
