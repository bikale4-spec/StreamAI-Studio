package com.streamai.studio.stream

import com.streamai.studio.core.StreamSettings

interface StreamingEngine {
 fun start(settings:StreamSettings)
 fun stop()
 fun isLive():Boolean
 fun setBitrate(kbps:Int)
}
class StreamingEngineAdapter:StreamingEngine {
 private var live=false
 override fun start(settings:StreamSettings){ /* Connect hardware encoder + RTMP/SRT SDK here. */ live=true }
 override fun stop(){live=false}
 override fun isLive()=live
 override fun setBitrate(kbps:Int){ /* encoder bitrate */ }
}
