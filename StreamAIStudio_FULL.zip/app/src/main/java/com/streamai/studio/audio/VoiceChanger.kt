package com.streamai.studio.audio

enum class VoicePreset { NORMAL, ROBOT, DEEP, CHIPMUNK, RADIO, ECHO }

interface VoiceChangerEngine {
 fun setPreset(preset:VoicePreset)
 fun setMix(amount:Float)
}
