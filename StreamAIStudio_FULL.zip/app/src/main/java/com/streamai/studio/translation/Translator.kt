package com.streamai.studio.translation

interface LiveTranslator {
 suspend fun speechToText(audio:ByteArray):String
 suspend fun translate(text:String,target:String):String
 suspend fun synthesize(text:String,language:String):ByteArray
}
