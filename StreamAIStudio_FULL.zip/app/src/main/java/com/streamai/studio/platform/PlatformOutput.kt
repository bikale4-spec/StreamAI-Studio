package com.streamai.studio.platform

interface PlatformOutput {
 fun connect()
 fun disconnect()
 fun send(streamUrl:String,streamKey:String)
}
