package com.streamai.studio.ai

interface BackgroundAI {
 fun enableSegmentation(enabled:Boolean)
 fun setBackgroundImage(path:String?)
 fun setBackgroundVideo(path:String?)
 fun setBlur(amount:Float)
}
