package com.streamai.studio.ai

sealed interface AssistantCommand {
 data object StartStream:AssistantCommand
 data object StopStream:AssistantCommand
 data object EnableTranslator:AssistantCommand
 data object EnableVoiceChanger:AssistantCommand
 data object EnableBackgroundRemoval:AssistantCommand
 data class ChangeScene(val scene:String):AssistantCommand
}

interface AIAssistant {
 suspend fun chat(message:String):String
 suspend fun execute(command:AssistantCommand):Boolean
}
