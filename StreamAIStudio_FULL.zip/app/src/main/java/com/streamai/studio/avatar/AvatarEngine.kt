package com.streamai.studio.avatar

interface AvatarEngine {
 fun load(id:String)
 fun faceTracking(enabled:Boolean)
 fun lipSync(enabled:Boolean)
}
