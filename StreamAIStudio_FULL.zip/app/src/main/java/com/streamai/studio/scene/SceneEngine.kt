package com.streamai.studio.scene

import com.streamai.studio.core.Scene

interface SceneEngine {
 fun add(scene:Scene)
 fun remove(id:String)
 fun activate(id:String)
 fun active():Scene?
}
class SceneEngineImpl:SceneEngine {
 private val scenes=mutableMapOf<String,Scene>()
 private var current:String?=null
 override fun add(scene:Scene){scenes[scene.id]=scene}
 override fun remove(id:String){scenes.remove(id)}
 override fun activate(id:String){if(scenes.containsKey(id))current=id}
 override fun active()=current?.let{scenes[it]}
}
