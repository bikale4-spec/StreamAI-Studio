package com.streamai.studio.capture

interface ScreenCaptureController {
 fun requestPermission()
 fun start()
 fun stop()
}
