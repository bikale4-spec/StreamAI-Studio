package com.streamai.studio.camera

interface CameraController {
 fun startFront()
 fun startBack()
 fun stop()
 fun switchCamera()
}
