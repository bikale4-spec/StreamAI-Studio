package com.streamai.studio.core

data class Scene(val id:String,val name:String,val sources:List<Source>)
data class Source(val id:String,val type:String,val enabled:Boolean=true)
data class StreamSettings(val url:String="",val key:String="",val bitrate:Int=4500,val fps:Int=30,val width:Int=1920,val height:Int=1080)
data class AudioState(val mic:Boolean=true,val game:Boolean=true,val music:Boolean=true,val voiceChanger:Boolean=false)
