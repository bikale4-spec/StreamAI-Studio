package com.streamai.studio.remote

interface RemoteControlHost {
 fun start()
 fun stop()
 fun pairingCode():String
 fun handle(command:String)
}
