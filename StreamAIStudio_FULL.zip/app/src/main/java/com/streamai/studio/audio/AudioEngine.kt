package com.streamai.studio.audio

interface AudioEngine {
 fun mic(enabled:Boolean)
 fun game(enabled:Boolean)
 fun music(enabled:Boolean)
 fun voiceChanger(enabled:Boolean)
 fun micVolume(value:Float)
 fun gameVolume(value:Float)
}
