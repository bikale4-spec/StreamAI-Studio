package com.streamai.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { StreamAIApp() }
 }
}

@Composable
fun StreamAIApp() {
 var live by remember { mutableStateOf(false) }
 val features = listOf(
  "🎥 Camera & Screen Capture",
  "🔴 Live Streaming / Recording",
  "🎬 Scenes & Overlays",
  "🎙️ Audio Mixer",
  "🔊 Voice Changer",
  "🟩 Green Screen / AI Background",
  "🌐 Live Translator & Subtitles",
  "🤖 AI Assistant",
  "🧠 AI Director",
  "🧑‍🚀 3D Avatar / Lip Sync",
  "🎭 Virtual Studio",
  "💬 Chat & Alerts",
  "✂️ Auto Clips",
  "📱 Second Phone Remote",
  "🌐 Multi-platform Output"
 )
 Scaffold(topBar={
  TopAppBar(title={Text("StreamAI Studio")},
   actions={Button(onClick={live=!live}){Text(if(live)"STOP" else "GO LIVE")}})
 }) { pad ->
  LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),
   verticalArrangement=Arrangement.spacedBy(10.dp)) {
   item { Text(if(live)"🔴 Live mode" else "Ready", style=MaterialTheme.typography.titleLarge) }
   features.forEach { feature ->
    item { ElevatedCard(Modifier.fillMaxWidth()) {
      Text(feature, Modifier.padding(18.dp))
    }}
   }
  }
 }
}
