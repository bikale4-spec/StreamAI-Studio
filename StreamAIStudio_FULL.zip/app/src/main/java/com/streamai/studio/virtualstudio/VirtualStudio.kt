package com.streamai.studio.virtualstudio

data class VirtualEnvironment(val id:String,val name:String)

interface VirtualStudio {
 fun load(environment:VirtualEnvironment)
 fun setCamera(x:Float,y:Float,z:Float)
}
