package com.streamai.studio.content

interface ClipEngine {
 fun markHighlight(timestampMs:Long)
 fun export(startMs:Long,endMs:Long,path:String)
}
