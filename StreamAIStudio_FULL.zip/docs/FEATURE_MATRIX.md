# Feature matrix

| Feature | Architecture | Needs external SDK/API |
|---|---|---|
| Camera | Controller | Optional |
| Screen capture | MediaProjection adapter | No |
| Recording | Encoder pipeline | No |
| RTMP/SRT | Streaming adapter | Encoder/library integration |
| Scenes | Scene engine | No |
| Overlays | Compositor | No |
| Voice changer | DSP adapter | Optional |
| Translation | Translator adapter | Usually yes |
| AI assistant | Command router | AI model/API |
| AI background | ML adapter | Model/runtime |
| 3D avatar | Avatar adapter | 3D engine/model |
| Remote phone | Local network host | No |
| Chat | Platform adapter | Platform APIs |
| Multi-platform | Platform adapters | Platform APIs |
